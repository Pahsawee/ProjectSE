# 3 Half Chess Project
# By SheepChess

#To Open The Server
 Run server.py to open the server (Be Sure to be connected to the same Local Network)

#To Play The Game
 Run chessMenu.py -> Click Start the game -> Enter Name and IP of the Server (Host)


